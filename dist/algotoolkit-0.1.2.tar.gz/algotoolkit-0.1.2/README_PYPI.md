# AlgoToolkit

A Python package for sorting and searching algorithms.

## 📦 Features
- **Sorting Algorithms:** Bubble Sort
- **Searching Algorithms:** Binary Search

## 📚 Installation
You can install the package directly from PyPI:

```bash
pip install algotoolkit